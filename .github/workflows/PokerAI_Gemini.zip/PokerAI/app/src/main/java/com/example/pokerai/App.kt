package com.example.pokerai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(i: Int) = (i * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        fun add(v: android.view.View, top: Int = 12) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        }
        add(TextView(this).apply { text = "Poker AI"; textSize = 26f; setTypeface(typeface, Typeface.BOLD) }, 0)
        status = TextView(this).apply { textSize = 14f }
        add(status, 8)
        val key = EditText(this).apply {
            hint = "Gemini API key (AIza...)"; setText(prefs.getString("akey", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        add(key, 20)
        val model = EditText(this).apply { hint = "Model"; setText((prefs.getString("amodel", "") ?: "").let { if (it.isEmpty() || it.startsWith("claude")) AiAgent.DEFAULT_MODEL else it }) }
        add(model, 10)
        val burl = EditText(this).apply { hint = "Base URL (optional, OpenAI-compatible, e.g. https://api.groq.com/openai/v1)"; setText(prefs.getString("aurl", "")) }
        add(burl, 10)
        add(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit().putString("akey", key.text.toString().trim())
                    .putString("aurl", burl.text.toString().trim())
                    .putString("amodel", model.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }, 14)
        add(Button(this).apply {
            text = "Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, 10)
        add(TextView(this).apply {
            text = "1) Save the API key.  2) Turn on Poker AI in Accessibility.  3) Tap the purple AI bubble; the AI opens the game and does the rest."
            textSize = 13f
        }, 16)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (PokerService.inst != null) "Service: ON" else "Service: OFF (turn it on in Accessibility)"
    }
}

class PokerService : AccessibilityService() {
    companion object { var inst: PokerService? = null }
    private var ai: AiAgent? = null

    override fun onServiceConnected() { inst = this; ai = AiAgent(this).also { it.showBubble() } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        ai?.hideBubble(); ai = null; inst = null
        return super.onUnbind(i)
    }

    fun tapPx(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    fun swipePx(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build(), null, null)
    }
}

class AiAgent(private val svc: PokerService) {
    private val h = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()
    private var running = false
    private var steps = 0
    private var bubble: TextView? = null
    private val history = ArrayDeque<String>()
    private var lastTap = ""
    private var sameTap = 0
    private var errCount = 0

    companion object {
        const val MAX_STEPS = 400
        const val GAME = "com.boyaa.androidmarketar"
        const val DEFAULT_MODEL = "gemini-3.5-flash"
        const val SYSTEM = """You control an Android phone and play the card game "Texas Poker" (Boyaa, Arabic UI). Screenshots may be landscape or portrait. Work fully on your own, like a human who reads every screen.
FULL FLOW, in order, whatever screen you see:
1) Google/Android screens: if a "Sign in with Google" / "Continue as ..." / Allow / Accept / I agree / متابعة / موافق / السماح button is visible, tap it. On a Google consent page swipe up until "Continue" is enabled, then tap Continue. Tick the "I agree / قرات ووافقت" box if shown.
2) Tutorial and pop-ups: tap the main button of every tutorial or welcome dialog (تعلم فورا / تعلم الآن / متابعة / موافق / التالي / حسنا / OK / Next / Start). If an arrow, hand or glow highlights something, tap exactly there. During tutorial hands follow the instruction text: tap the highlighted button, otherwise the green Check/Call button. Never raise or go all-in.
3) Rewards: from the lobby open Mission (المهام), and in EVERY tab (مهام المبتدئين, مهمة يومية, مهمة انجازات) tap each active gold claim button (تلقي / استلام / Collect / Claim). Ignore grey buttons or ones that say "تم". If a mission needs playing hands, go to a table (بدأ سريع) and play with Check/Call only.
4) Close any promo/ad/news pop-up with its X or Close.
5) When nothing is left to claim and no tutorial remains, answer done.
PRECISION: tap the exact CENTER of the button or highlighted spot. Never guess; if the screen is loading, animating, or you cannot clearly see the target, answer wait. If your last tap did not change the screen, try a different spot or the back action instead of repeating it.
HARD RULES: NEVER tap anything about shop, store, recharge, top-up, buy, purchase, deposit, payment, subscriptions, watching ads, invite/share, or any real-money item. Never type text. If unsure, answer wait.
Answer with ONE JSON object only, no other text:
{"action":"tap","x":0-1000,"y":0-1000,"why":"short reason"}  (x,y inside the image: 0,0 top-left, 1000,1000 bottom-right)
or {"action":"swipe","x":..,"y":..,"x2":..,"y2":..} or {"action":"back"} or {"action":"wait"} or {"action":"done"}."""
    }

    fun showBubble() {
        if (bubble != null) return
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = svc.resources.displayMetrics.density
        val size = (52 * d).toInt()
        val tv = TextView(svc).apply {
            text = "AI"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        }
        val lp = WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = (200 * d).toInt() }
        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (running) stop() else start() }
            }
            true
        }
        wm.addView(tv, lp); bubble = tv; paint()
    }

    fun hideBubble() {
        stop()
        bubble?.let { (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        bubble = null
    }

    private fun paint() {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (running) 0xFF1B8E3E.toInt() else 0xFF6D28D9.toInt())
            setStroke(4, 0x66FFFFFF)
        }
    }

    private fun toast(t: String) = h.post { Toast.makeText(svc, t, Toast.LENGTH_LONG).show() }

    private fun start() {
        val key = svc.getSharedPreferences("p", Context.MODE_PRIVATE).getString("akey", "")?.trim().orEmpty()
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ required"); return }
        if (key.isEmpty()) { toast("Write the API key in the Poker AI app first"); return }
        svc.packageManager.getLaunchIntentForPackage(GAME)?.let {
            svc.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        running = true; steps = 0; errCount = 0; history.clear(); lastTap = ""; sameTap = 0; paint()
        h.postDelayed({ step() }, 3000)
    }

    fun stop() { running = false; h.removeCallbacksAndMessages(null); paint() }

    private fun step() {
        if (!running || Build.VERSION.SDK_INT < 30) return
        if (steps++ >= MAX_STEPS) { toast("AI: max steps"); stop(); return }
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) { h.post { stop() }; return }
                    val reply = ask(encode(bmp))
                    errCount = 0
                    h.post { act(reply, bmp.width, bmp.height) }
                } catch (e: Exception) {
                    errCount++
                    toast("AI error ($errCount/5): " + (e.message ?: e.javaClass.simpleName))
                    if (errCount >= 5) h.post { stop() } else h.postDelayed({ step() }, 3000)
                }
            }
            override fun onFailure(code: Int) {
                if (code == 3) { h.postDelayed({ step() }, 400); return }
                errCount++
                toast("Screenshot failed ($code) $errCount/5")
                if (errCount >= 5) h.post { stop() } else h.postDelayed({ step() }, 1000)
            }
        })
    }

    private fun encode(src: Bitmap): String {
        val w = 768
        val hh = (src.height * w / src.width.toFloat()).toInt()
        val s = Bitmap.createScaledBitmap(src, w, hh, true)
        val o = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun ask(b64: String): String {
        val p = svc.getSharedPreferences("p", Context.MODE_PRIVATE)
        val key = p.getString("akey", "")?.trim().orEmpty()
        var model = p.getString("amodel", DEFAULT_MODEL)?.trim().orEmpty()
        if (model.isEmpty() || model.startsWith("claude")) model = DEFAULT_MODEL
        val hist = if (history.isEmpty()) "none" else history.joinToString(" | ")
        val baseUrl = p.getString("aurl", "")?.trim()?.trimEnd('/').orEmpty()
        if (baseUrl.isNotEmpty()) {
            val oaModel = p.getString("amodel", "")?.trim().orEmpty()
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", "Your last actions: $hist\nWhat is the next single action? Reply with JSON only."))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
            val oaBody = JSONObject().put("model", oaModel).put("max_tokens", 300).put("temperature", 0.0)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", content)))
            val oc = URL("$baseUrl/chat/completions").openConnection() as HttpURLConnection
            oc.requestMethod = "POST"; oc.connectTimeout = 20000; oc.readTimeout = 60000; oc.doOutput = true
            oc.setRequestProperty("content-type", "application/json")
            oc.setRequestProperty("Authorization", "Bearer $key")
            oc.outputStream.use { it.write(oaBody.toString().toByteArray()) }
            val ocode = oc.responseCode
            val otxt = (if (ocode in 200..299) oc.inputStream else oc.errorStream).bufferedReader().readText()
            if (ocode !in 200..299) throw RuntimeException("HTTP $ocode [$oaModel] " + otxt.replace("\n", " ").take(400))
            return JSONObject(otxt).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
        val parts = JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("text", "Your last actions: $hist\nWhat is the next single action?"))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 300).put("temperature", 0.0)
                .put("responseMimeType", "application/json"))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) {
            val msg = try {
                val e = JSONObject(txt).getJSONObject("error")
                e.optString("status") + ": " + e.optString("message")
            } catch (x: Exception) { txt }
            throw RuntimeException("HTTP $code [$model] " + msg.replace("\n", " ").take(400))
        }
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun act(reply: String, w: Int, hh: Int) {
        if (!running) return
        val a = try {
            JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            history.addLast("unparsable"); h.postDelayed({ step() }, 500); return
        }
        when (a.optString("action")) {
            "tap" -> {
                val x = a.optDouble("x", -1.0)
                val y = a.optDouble("y", -1.0)
                if (x !in 0.0..1000.0 || y !in 0.0..1000.0) { h.postDelayed({ step() }, 500); return }
                val k = "${(x / 40).toInt()},${(y / 40).toInt()}"
                sameTap = if (k == lastTap) sameTap + 1 else 0
                lastTap = k
                if (sameTap >= 6) { toast("AI: stuck, stopped"); stop(); return }
                svc.tapPx((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat())
                history.addLast("tap(${x.toInt()},${y.toInt()}) " + a.optString("why").take(40))
                h.postDelayed({ step() }, 500)
            }
            "swipe" -> {
                val x = a.optDouble("x", 500.0)
                val y = a.optDouble("y", 700.0)
                val x2 = a.optDouble("x2", x)
                val y2 = a.optDouble("y2", 300.0)
                svc.swipePx((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat(),
                    (x2 / 1000.0 * w).toFloat(), (y2 / 1000.0 * hh).toFloat())
                history.addLast("swipe"); h.postDelayed({ step() }, 600)
            }
            "back" -> {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                history.addLast("back"); h.postDelayed({ step() }, 700)
            }
            "wait" -> { history.addLast("wait"); h.postDelayed({ step() }, 1200) }
            "done" -> { toast("AI: done"); stop() }
            else -> h.postDelayed({ step() }, 500)
        }
        while (history.size > 8) history.removeFirst()
    }
}
